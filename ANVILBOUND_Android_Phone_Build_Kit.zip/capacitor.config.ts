import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.emberfall.anvilbound',
  appName: 'ANVILBOUND',
  webDir: 'dist',
};

export default config;
