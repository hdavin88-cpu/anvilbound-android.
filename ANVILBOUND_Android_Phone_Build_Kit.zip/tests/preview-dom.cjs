const fs=require('fs'),vm=require('vm');
const path=require('path');
const html=fs.readFileSync(path.resolve(__dirname,'../../ANVILBOUND_Animated_Playable_Preview.html'),'utf8');const script=html.split('<script>')[1].split('</script>')[0];
const nodes=new Map(),listeners={};
const classList=()=>({add(){},remove(){},toggle(){},contains(){return true}});
function node(id){if(nodes.has(id))return nodes.get(id);const x={id,style:{},dataset:{},clientHeight:345,files:[],classList:classList(),setAttribute(){},click(){},addEventListener(type,fn){listeners[id+':'+type]=fn},remove(){},get textContent(){return this._text},set textContent(v){this._text=v},get innerHTML(){return this._html||''},set innerHTML(v){this._html=String(v);for(const m of this._html.matchAll(/\bid="([^"]+)"/g))node(m[1])},get value(){return this._value??''},set value(v){this._value=v}};nodes.set(id,x);return x}
node('app');const head={appendChild(el){if(el.onerror)el.onerror()}};
const document={head,body:{dataset:{}},hidden:false,visibilityState:'visible',createElement:(tag)=>({tag,style:{},click(){},remove(){},set src(s){this._src=s},get src(){return this._src}}),getElementById:id=>nodes.get(id)||null,querySelector:sel=>node(sel.replace('#','')),addEventListener:(kind,fn)=>{listeners['document:'+kind]=fn}};
const local=new Map();const window={addEventListener(){},scrollTo(){},setTimeout(fn){return 1},clearTimeout(){},URL:{createObjectURL(){return 'blob:test'},revokeObjectURL(){}}};const sandbox={document,window,localStorage:{getItem:k=>local.get(k)??null,setItem:(k,v)=>local.set(k,v)},matchMedia:()=>({matches:false}),performance:{now:()=>1},requestAnimationFrame(){},setTimeout(fn){return 1},clearTimeout(){},Blob,console,Date,Math,JSON,Number,URL};
vm.createContext(sandbox);vm.runInContext(script,sandbox,{timeout:15000});
const assert=(ok,label)=>{if(!ok)throw Error('FAILED '+label);console.log('PASS',label)};
const model=window.__ANVILBOUND_MODEL__;
assert(!!model,'startup created ForgeGame');
assert(document.body.dataset.engine==='fallback','local fallback used without Phaser network');
assert(node('content').innerHTML.includes('Crafting Blueprints'),'forge panel rendered');
assert(node('game-canvas').innerHTML.includes('fb-hammer'),'animated workshop layers rendered');
model.startForge();assert(node('content').innerHTML.includes('STRIKE NOW!'),'active forging timing control rendered');
for(let i=0;i<3;i++){model.state.active.cursor=model.state.active.target;model.strike()}
assert(model.state.inventory.length===1,'forged item reaches inventory');
model.dismissItem();model.setTab('market');assert(node('content').innerHTML.includes('Equipment Display'),'market display rendered');
const item=model.state.inventory[0];model.sellInstant(item.id);assert(model.state.gold>500,'sale increases treasury');
model.setTab('contracts');assert(node('content').innerHTML.includes('Commission Board'),'commission screen rendered');
model.setTab('upgrade');assert(node('content').innerHTML.includes('Hammer Mastery'),'upgrades screen rendered');
model.setTab('save');assert(node('content').innerHTML.includes('Import Backup'),'save vault rendered');
assert(local.has('anvilbound.save.v1'),'local save key preserved');
console.log('DOM integration smoke tests passed.');
