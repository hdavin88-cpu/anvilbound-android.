const fs=require('fs'),vm=require('vm');let ts;try{ts=require('typescript')}catch{ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript')}
function compile(path){const src=fs.readFileSync(path,'utf8');let out=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;return out.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');}
const storage=new Map();const sandbox={console,Math,Date,Number,JSON,localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)},structuredClone,window:{},globalThis:{}};
const files=['src/game/catalog.ts','src/game/engine.ts'].map(x=>__dirname+'/../'+x);
vm.createContext(sandbox);vm.runInContext(files.map(compile).join('\n')+'\nthis.ForgeGame=ForgeGame;this.unpackBackup=unpackBackup;this.freshState=freshState;this.SAVE_KEY=SAVE_KEY;',sandbox);
const assert=(truth,desc)=>{if(!truth)throw Error('FAIL '+desc);console.log('PASS',desc)};
const game=new sandbox.ForgeGame();
assert(game.state.gold===500 && game.state.level===1 && game.state.commission.length===3,'fresh game, initial economy, 3 contracts');
assert(storage.has(sandbox.SAVE_KEY),'initial autosave');
const oldGold=game.state.gold;
assert(game.startForge().ok,'start forging consumes materials');
assert(game.state.materials.iron===12,'material requirements preserved');
let result;
for(let i=0;i<3;i++){game.state.active.cursor=game.state.active.target;result=game.strike()}
assert(result.complete && game.state.inventory.length===1 && game.state.crafted===1,'three precision strikes create an item');
const it=game.state.inventory[0];assert(it.rank>=1&&it.precision===100,'quality and rarity calculated');
const exported=game.exportData();assert(exported.kind==='anvilbound-save'&&exported.formatVersion===2,'legacy-compatible exported format');
const sold=game.sellInstant(it.id);assert(sold.ok && game.state.gold>oldGold && game.state.sold===1,'instant sale yields gold and fame');
const savedGold=game.state.gold;const restored=new sandbox.ForgeGame();assert(restored.state.gold===savedGold&&restored.state.sold===1,'autosave reload from same storage');
restored.import(exported);assert(restored.state.inventory.length===1&&restored.state.crafted===1,'backup restore recovers earlier inventory');
restored.setStrategy('premium');assert(restored.listItem(it.id).ok&&restored.state.listings.length===1,'premium market listing');
restored.cancelListing(restored.state.listings[0].id);assert(restored.state.inventory.length===1,'recall listing returns item');
const before=restored.state.day;assert(restored.endDay().ok&&restored.state.day===before+1,'end of day changes demand and pays upkeep');
const state=JSON.parse(JSON.stringify(restored.state));const legacy= sandbox.unpackBackup(state);assert(legacy.day===restored.state.day,'import raw v1 legacy state');
let rejects=false;try{sandbox.unpackBackup({kind:'anvilbound-save',formatVersion:999,data:state})}catch{rejects=true}assert(rejects,'malformed backup rejected');
assert(restored.buyMaterial('iron').ok,'material purchasing');
const up=restored.state.gold>=restored.upgradePrice('hammer');if(up)assert(restored.upgrade('hammer').ok,'upgrade purchase');
restored.reset();assert(restored.state.gold===500&&restored.state.day===1,'reset restores starting game');
console.log('All engine smoke tests passed.');
