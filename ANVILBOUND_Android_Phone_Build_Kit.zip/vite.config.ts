import {defineConfig} from 'vite';
import {viteSingleFile} from 'vite-plugin-singlefile';
export default defineConfig({base:'./',plugins:[viteSingleFile()],build:{target:'es2022',assetsInlineLimit:1048576,cssCodeSplit:false,chunkSizeWarningLimit:1800}});
