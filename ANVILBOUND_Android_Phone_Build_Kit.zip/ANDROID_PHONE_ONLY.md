# ANVILBOUND — Android phone-only build guide

You do **not** need a Windows PC, Mac, or Android Studio on your phone. GitHub Codespaces is the web-based editor and GitHub Actions runs the Android SDK in the cloud. You do need a GitHub account and Internet access. GitHub usage quotas or charges may apply; check your account billing limits.

This package is **source code with a cloud APK build recipe**, not an APK yet. The cloud workflow is supplied but has NOT been run successfully in this authoring environment. It is for personal/testing use, producing a debug-signed APK; do not upload that APK directly as a Play Store production release.

## Phone-only instructions

1. In ChatGPT, download `ANVILBOUND_Android_Phone_Build_Kit.zip` to your phone. Do not rename files inside the ZIP.
2. Open **https://github.com/new** in Chrome, sign in or create your own GitHub account, and create a new **private** repository named `anvilbound-android`. Tick **Add a README file** so the repository has a default branch (normally `main`). Using Chrome's *Desktop site* option may make the controls easier to find.
3. In that repository open **Code → Codespaces → Create codespace on main**. GitHub opens the browser version of VS Code; you do not need an Android VS Code app. If you cannot see `Codespaces` on mobile, enable Chrome's *Desktop site* view.
4. In the Codespaces **Explorer**, open the root folder's context menu and choose **Upload...**. Pick the downloaded ZIP using Android's file picker. GitHub Codespaces supports browser file uploads; mobile menu wording may vary. The ZIP should now appear in the workspace root.
5. In Codespaces choose **Terminal → New Terminal** and run exactly this (case-sensitive):

   ```bash
   unzip -o ANVILBOUND_Android_Phone_Build_Kit.zip -d .
   rm ANVILBOUND_Android_Phone_Build_Kit.zip
   git add -A
   git commit -m "Add ANVILBOUND Phaser and Android cloud build"
   git push
   ```

   The ZIP contains files at its root and `.github/workflows/android-debug-apk.yml` so GitHub Actions can discover the build. If `git commit` asks for your name/email, set them in Codespaces with `git config --global user.name ...` and `git config --global user.email ...`, using your own details, then retry. If `git push` requires permission, use GitHub's built-in Codespaces sign-in and Source Control interface.

6. Return to your GitHub repository in Chrome and open **Actions → Build ANVILBOUND Android APK**. Pushing to `main` normally starts the workflow automatically. Alternatively tap **Run workflow**. Open the run to see the cloud build status.
7. When the run has a green check, go to the run's **Artifacts** section and download **ANVILBOUND-Android-Debug-APK**. If GitHub downloads a ZIP, extract it using your Android Files/My Files app, then find `app-debug.apk`.
8. Tap `app-debug.apk` to install. Android may ask permission to install apps from Chrome/My Files; enable it only for the source you're using, and turn it off again afterward. Samsung's Auto Blocker may block sideloading; understand the security warning before changing settings. Keep Play Protect enabled. This APK came from your own cloud build.
9. Before replacing any existing ANVILBOUND edition, export its **Save Vault JSON** and import it into the APK. Android apps and browsers use separate local storage.

## First validate the browser build in Codespaces (optional but recommended)

In the Codespaces terminal:

```bash
npm install
npm run dev
```

Codespaces may detect the Vite server on port 5173. In the **Ports** panel, open its forwarded URL in another Chrome tab. This lets you test the Phaser build on your Android phone before spending time on APK builds.

## Troubleshooting

- **GitHub Actions not starting:** confirm that `.github/workflows/android-debug-apk.yml` exists in the repository's `main` branch. GitHub may need Actions enabled for a new repository.
- **Upload ZIP not found by terminal:** ensure the upload went into the workspace root rather than a subfolder. Use `ls` to inspect.
- **Gradle/SDK failure:** open the failed GitHub Actions job; copy the error log to ChatGPT for troubleshooting. Capacitor and Android tooling can change.
- **APK installs but shows a blank screen:** send browser testing information or Android WebView version; the APK is not yet device-verified.
- **Save data seems missing:** browser-origin storage does not migrate automatically. Use JSON export/import.
- **GitHub mobile UI is awkward:** switch Chrome to *Desktop site* and use landscape while handling Codespaces, then return to portrait for game testing.

## Architecture

- Phaser 3.90 + TypeScript + Vite: animated 2D game
- Capacitor 8.5.3: native Android WebView wrapper
- GitHub Actions: Java 21 + Android SDK 36 + `gradlew assembleDebug`
- Result: **debug-signed** installable APK, not a signed Play Store release

Documentation:
- https://docs.github.com/en/codespaces/developing-in-a-codespace/developing-in-a-codespace
- https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
- https://capacitorjs.com/docs/getting-started
- https://developer.android.com/build/building-cmdline
