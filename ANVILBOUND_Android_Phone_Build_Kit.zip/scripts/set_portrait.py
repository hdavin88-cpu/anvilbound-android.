"""Limit the demo APK to portrait on phones; keep gameplay web layout responsive."""
from pathlib import Path
manifest = Path('android/app/src/main/AndroidManifest.xml')
source = manifest.read_text(encoding='utf-8')
target = 'android:name=".MainActivity"'
if source.count(target) != 1:
    raise SystemExit('Expected one MainActivity in AndroidManifest.xml; review the generated manifest')
if 'android:screenOrientation="portrait"' not in source:
    source = source.replace(target, target + '\n            android:screenOrientation="portrait"', 1)
    manifest.write_text(source, encoding='utf-8')
print('Android portrait orientation configured')
