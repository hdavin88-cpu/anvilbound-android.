from pathlib import Path
import re, html
import cairosvg
from PIL import Image
import sys
root=Path(__file__).parent/'public/assets'
legacy=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent.parent/'Anvilbound_Cartoon_Edition.html'
if not legacy.exists():
  raise SystemExit('To regenerate original base artwork, pass the path to Anvilbound_Cartoon_Edition.html as the first argument.')
text=legacy.read_text()
frag=text.split('function anvilIllustration(recipeId,isActive){',1)[1].split('</svg>`;',1)[0]
frag=frag[frag.index('<svg'):]+ '</svg>'
frag=frag.replace('${blaze}','#ffdc69').replace("${isActive?'-12':'-3'}",'-3')
start=frag.index('<!-- dwarf-like chibi blacksmith')
hammer=frag.index('<!-- raised hammer')
anvil=frag.index('<!-- anvil, placed')
weapon=frag.index('<!-- glowing weapon')
end=frag.rindex('</svg>')
pre=frag[:frag.index('<!-- dwarf-like chibi blacksmith')]
ns='xmlns="http://www.w3.org/2000/svg"'
# SVGs are all based on original ANVILBOUND artwork, split into animatable layers
svg_bg=pre+'</svg>'
svg_smith=f'<svg {ns} viewBox="197 86 202 300" width="404" height="600">'+frag[start:hammer]+'</svg>'
svg_hammer=f'<svg {ns} viewBox="358 133 100 145" width="200" height="290">'+frag[hammer:anvil]+'</svg>'
svg_anvil=f'<svg {ns} viewBox="365 225 260 165" width="520" height="330"><defs><linearGradient id="workSteel" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#a0def2"/><stop offset=".45" stop-color="#6e99b7"/><stop offset="1" stop-color="#3a527f"/></linearGradient></defs>'+frag[anvil:end]+'</svg>'
for name,raw,w in [('forge-bg',svg_bg,1600),('smith',svg_smith,404),('hammer',svg_hammer,200),('anvil',svg_anvil,520)]:
  p=root/(name+'.svg');p.write_text(raw)
  try:
    cairosvg.svg2png(bytestring=raw.encode('utf-8'),write_to=str(root/(name+'.png')),output_width=w)
    im=Image.open(root/(name+'.png')); print(name,im.size)
  except Exception as e:print('render failed',name,e)
# Additional original shop art; not third-party graphics.
shop='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 420" width="1600" height="840">
<defs><linearGradient id="wall" x2="0" y2="1"><stop stop-color="#bbecf8"/><stop offset="1" stop-color="#f3ddae"/></linearGradient><linearGradient id="floor" x2="0" y2="1"><stop stop-color="#d0a26c"/><stop offset="1" stop-color="#9d6b55"/></linearGradient><linearGradient id="light" x2="0" y2="1"><stop stop-color="#fff4a0"/><stop offset="1" stop-color="#ffab62"/></linearGradient></defs>
<rect width="800" height="420" fill="url(#wall)"/><path d="M0 0h800v67H0Z" fill="#efc77a" stroke="#34496f" stroke-width="8"/><path d="M0 40h800" stroke="#fff2b2" stroke-width="9"/>
<path d="M0 274h800v146H0Z" fill="url(#floor)" stroke="#35486b" stroke-width="9"/>
<path d="M0 332h800M0 382h800M137 276v55M300 332v50M567 275v54M713 330v52" stroke="#885d54" stroke-width="5" opacity=".42"/>
<path d="M32 81h244v179H32Z" fill="#876c7b" stroke="#344668" stroke-width="9"/><path d="M46 95h216v155H46Z" fill="#dbc392" stroke="#fff0ab" stroke-width="5"/><path d="M42 143h222M42 207h222" stroke="#845f65" stroke-width="13"/>
<g stroke="#35476a" stroke-width="5" stroke-linejoin="round"><path d="M72 134l-7-23h37l-7 23Z" fill="#e2a9a8"/><path d="M119 133l-7-28h44l-8 28Z" fill="#94bdd9"/><path d="M191 127l-8-19h40l-8 19Z" fill="#8bc9ba"/><path d="M72 198l-5-30h33l-7 30Z" fill="#f4b458"/><path d="M128 196l-4-31h29l-4 31Z" fill="#c7b6e9"/><path d="M191 198l-5-29h36l-7 29Z" fill="#f29e87"/></g>
<path d="M540 86h218v180H540Z" fill="#b77b6b" stroke="#344969" stroke-width="11"/><path d="M551 97h196v150H551Z" fill="#87d1e9" stroke="#ffedaf" stroke-width="6"/><path d="M650 91v166" stroke="#344969" stroke-width="8"/><path d="M555 243h190" stroke="#efc67c" stroke-width="11"/>
<path d="M554 225q56-92 99-8q44-91 88 1v23H553Z" fill="#65b78c"/><path d="M562 241q59-55 91-6q40-55 83-4" fill="#479d9d"/><circle cx="720" cy="128" r="23" fill="#fff19d"/>
<path d="M0 282h417l18 115H0Z" fill="#ba785d" stroke="#35456c" stroke-width="8"/><path d="M0 284h421v29H0Z" fill="#f9c674" stroke="#35456c" stroke-width="6"/><path d="M0 309h419" stroke="#fff0ad" stroke-width="5"/>
<path d="M160 282v-62h86v62" fill="#8eacd3" stroke="#34476b" stroke-width="7"/><path d="M169 232h70v45h-70Z" fill="#a9e1ed"/><path d="M194 222v-52h15v52" stroke="#35476b" stroke-width="5"/><circle cx="200" cy="164" r="23" fill="url(#light)" stroke="#3b486a" stroke-width="5"/>
<g stroke="#314669" stroke-linejoin="round" stroke-width="6"><path d="M82 264l11-47h36l12 47Z" fill="#a9b0da"/><path d="M93 221v-40h34v40Z" fill="#b8dbed"/><path d="M91 179h41"/><path d="M322 255l9-51h41l9 51Z" fill="#7bc7ac"/><path d="M340 211v-38h24v38Z" fill="#f9e096"/><path d="M340 178h24"/></g>
<g stroke="#33476b" stroke-width="7"><path d="M453 48h52v78h-52Z" fill="#f3b35c"/><path d="M464 66h30" stroke="#fff3ab"/><path d="M474 74v40" stroke="#fff3ab"/></g><text x="477" y="146" text-anchor="middle" font-size="19" font-weight="900" fill="#31486d" font-family="sans-serif">SHOP</text>
<ellipse cx="492" cy="367" rx="245" ry="28" fill="#614b5c" opacity=".2"/>
</svg>'''
(root/'shop-bg.svg').write_text(shop)
cairosvg.svg2png(bytestring=shop.encode(),write_to=str(root/'shop-bg.png'),output_width=1600)
# 3 original chibi visitor variants: simple modular clean vector design
for name,body,hair,cloak,hat in [
 ('knight','#7eb6d7','#9c634b','#4679b7','#ffe07d'),
 ('mage','#c6a1ec','#81618f','#8666c1','#9ed7e5'),
 ('ranger','#8ac99e','#9a5b4c','#548e6b','#eabb74')]:
 svg=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 245" width="320" height="490">
<ellipse cx="83" cy="231" rx="60" ry="11" fill="#566280" opacity=".2"/>
<g stroke="#2e466c" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">
<path d="M51 168l-6 54h35l6-42Z" fill="#4c5c86"/><path d="M91 181l1 41h35l-5-55Z" fill="#4c5c86"/>
<path d="M42 218q-17 17 6 20h36q14-14-11-21Z" fill="#8a626c"/><path d="M92 219q-7 17 15 19h27q13-16-15-20Z" fill="#8a626c"/>
<path d="M48 143q-20 24-13 65l38 16q14-47 15-53q16 44 47 53l-8-72Z" fill="{cloak}"/>
<path d="M52 141h72l8 65H46Z" fill="{body}"/>
<path d="M47 148l-27 29 18 14 29-26" fill="#f3bd92"/><path d="M120 146l26 30-16 14-24-26" fill="#f3bd92"/>
<path d="M72 156v46M104 156v46" stroke="#fff1bd" stroke-width="7"/>
<circle cx="80" cy="87" r="61" fill="#f8c394"/><ellipse cx="22" cy="100" rx="12" ry="17" fill="#f2ac80"/><ellipse cx="136" cy="100" rx="12" ry="17" fill="#f2ac80"/>
<path d="M20 82Q12 14 59 17Q98-2 126 24Q161 48 138 94l-14-24q-16 5-25-8Q68 78 42 66l-20 24Z" fill="{hair}"/>
<path d="M28 46Q80 8 128 48" fill="none" stroke="{hat}" stroke-width="13"/>
<ellipse cx="59" cy="102" rx="8" ry="12" stroke="none" fill="#314766"/><ellipse cx="104" cy="102" rx="8" ry="12" stroke="none" fill="#314766"/>
<circle cx="62" cy="99" r="3" stroke="none" fill="white"/><circle cx="106" cy="99" r="3" stroke="none" fill="white"/>
<path d="M73 124q10 11 18 0" fill="none" stroke="#a45f65" stroke-width="4"/><ellipse cx="37" cy="118" rx="12" ry="6" fill="#eb918d" stroke="none"/><ellipse cx="125" cy="118" rx="12" ry="6" fill="#eb918d" stroke="none"/>
</g></svg>'''
 (root/(name+'.svg')).write_text(svg)
 cairosvg.svg2png(bytestring=svg.encode(),write_to=str(root/(name+'.png')),output_width=320)
print('assets', [(p.name,p.stat().st_size) for p in root.glob('*.png')])
