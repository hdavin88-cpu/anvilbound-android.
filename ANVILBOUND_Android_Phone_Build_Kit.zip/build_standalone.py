from pathlib import Path
import base64,json,subprocess,re
root=Path(__file__).parent
code_dir=root/'src'
modules=[code_dir/'game/catalog.ts',code_dir/'game/engine.ts',code_dir/'scenes/WorkshopScene.ts',code_dir/'ui/ui.ts']
# Runtime preview compiles the SAME TypeScript model and UI sources. In connected browsers
# it loads the actual Phaser runtime; without CDN, an animated DOM viewport is used.
node_script=r'''
const fs=require('fs');const path=require('path');let ts;try{ts=require('typescript')}catch{ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');}
let input=fs.readFileSync(process.argv[1],'utf8');if(process.argv[1].endsWith('/ui/ui.ts'))input=input.replace('`${import.meta.env.BASE_URL}assets/item-${id}.png`','ITEM_IMG[id]');
let output=ts.transpileModule(input,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,removeComments:true}}).outputText;
output=output.replace(/^import .*?;\s*$/gm,'').replace(/^export /gm,'');
process.stdout.write(output);
'''
compiled=[]
for f in modules:
 r=subprocess.run(['node','-e',node_script,str(f)],capture_output=True,text=True,cwd=root)
 if r.returncode: raise RuntimeError(f'{f} transpile failed: {r.stderr}')
 # Ensure no module remnants
 assert not re.search(r'^import\b|^export\b',r.stdout,re.M),f
 compiled.append(r.stdout)
# Scene must only be evaluated after Phaser has loaded. Otherwise the offline fallback
# cannot initialize because the base Phaser.Scene class would be undefined.
compiled[2]='function createWorkshopScene(){\n'+compiled[2]+'\nreturn WorkshopScene;\n}'
name_map={'anvil':'anvilImg','smith':'smithImg','hammer':'hammerImg','forge-bg':'forgeBg','shop-bg':'shopBg','knight':'knightImg','mage':'mageImg','ranger':'rangerImg'}
assets={name_map[p.stem]:('data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()) for p in (code_dir/'assets').glob('*.png')}
items={p.stem[5:]:('data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()) for p in (root/'public/assets').glob('item-*.png')}
assetvars='const '+', '.join(f'{name}={json.dumps(data)}' for name,data in assets.items())+';\n'
app_js='''
const ITEM_IMG=__ITEM_IMG__;
__ASSET_VARS__
__COMPILED__
class AnimatedFallback {
  constructor(model){this.model=model;this.onFrame=null;this.market=false;this.lastTick=performance.now();this.inner=null;this.customerVariant=0;}
  attach(){const stage=document.querySelector('#game-canvas');if(!stage)return;
    stage.innerHTML=`<div class="fallback-world" id="fallback-world">
      <div class="fallback-forge">
        <img class="fb-bg" src="${forgeBg}"/><img class="fb-smith" src="${smithImg}"/>
        <img class="fb-hammer" id="fb-hammer" src="${hammerImg}"/><img class="fb-anvil" src="${anvilImg}"/>
        <i class="fb-glow"></i><i class="fb-spark one"></i><i class="fb-spark two"></i><i class="fb-spark three"></i>
      </div><div class="fallback-shop">
        <img class="fb-bg" src="${shopBg}"/><img class="fb-shop-smith" src="${smithImg}"/><img id="fb-customer" class="fb-customer" src="${knightImg}"/>
        <div class="fb-speech">A customer is browsing…</div>
      </div><div class="fb-effect" id="fb-effect"></div>
    </div>`;
    this.inner=document.querySelector('#fallback-world');this.resize();window.addEventListener('resize',()=>this.resize());
    const c=document.querySelector('#fb-customer');c.addEventListener('click',()=>this.model.setTab('contracts'));
    this.setTab(this.model.state.tab);
    requestAnimationFrame(now=>this.frame(now));
  }
  resize(){if(!this.inner)return;const h=document.getElementById('game-canvas').clientHeight;this.inner.style.transform=`translate(-50%,-50%) scale(${h/420})`;}
  frame(now){if(!document.hidden){this.model.tick(Math.min(80,now-this.lastTick));const a=this.model.state.active;if(a)this.onFrame?.(a.cursor,a.target,a.phase);}this.lastTick=now;requestAnimationFrame(t=>this.frame(t));}
  setTab(tab){this.market=tab==='market'||tab==='contracts';this.inner?.classList.toggle('show-market',this.market);if(this.market){const choices=[knightImg,mageImg,rangerImg];this.customerVariant=(this.customerVariant+1)%3;document.querySelector('#fb-customer').src=choices[this.customerVariant];}}
  flash(text){const el=document.getElementById('fb-effect');if(!el)return;el.innerText=text;el.classList.remove('animated');void el.offsetWidth;el.classList.add('animated')}
  strikeEffect(score,complete){const hammer=document.getElementById('fb-hammer');if(hammer){hammer.classList.remove('strike');void hammer.offsetWidth;hammer.classList.add('strike');}this.flash(complete?'✨ MASTERPIECE!':score>=92?'✨ PERFECT!':score>=72?'💥 GREAT HIT!':'💥 STRIKE!')}
  revealEffect(item){this.flash(`✦ ${rarities[item.rank].name.toUpperCase()} ✦`)}
  saleEffect(){this.flash('🪙 + GOLD!')}
  levelUpEffect(){this.flash('✨ LEVEL UP!')}
}
function bootPreview(){if(window.__ANVILBOUND_STARTED__)return;window.__ANVILBOUND_STARTED__=true;
 const model=new ForgeGame();let scene;
 if(window.Phaser){
   try{const SceneCtor=createWorkshopScene();scene=new SceneCtor(model);mountUI(model,scene);new Phaser.Game({type:Phaser.AUTO,parent:'game-canvas',width:800,height:420,backgroundColor:'#b9e1ed',scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},render:{antialias:true},scene:[scene]});document.body.dataset.engine='phaser';}
   catch(e){console.warn('Phaser launch failed; using animated browser fallback',e);window.__ANVILBOUND_STARTED__=false;document.getElementById('app').innerHTML='';window.Phaser=undefined;bootPreview();return}
 }else{scene=new AnimatedFallback(model);mountUI(model,scene);scene.attach();document.body.dataset.engine='fallback';}
 window.__ANVILBOUND_MODEL__=model;
 window.addEventListener('pagehide',()=>model.save());document.addEventListener('visibilitychange',()=>{if(document.hidden)model.save()});
}
const phaserScript=document.createElement('script');phaserScript.src='https://cdnjs.cloudflare.com/ajax/libs/phaser/3.90.0/phaser.min.js';phaserScript.async=true;
phaserScript.onload=()=>bootPreview();phaserScript.onerror=()=>bootPreview();document.head.appendChild(phaserScript);
setTimeout(()=>bootPreview(),2200);
'''
app_js=app_js.replace('__ITEM_IMG__',json.dumps(items)).replace('__ASSET_VARS__',assetvars).replace('__COMPILED__','\n'.join(compiled))
css=(code_dir/'ui/style.css').read_text();css=css.replace("@import url('https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@500;600;700;800;900&display=swap');",'')
css+='''
.fallback-world{position:absolute;left:50%;top:50%;width:800px;height:420px;transform:translate(-50%,-50%);transform-origin:center;overflow:hidden;background:#9fd1e6}
.fallback-forge,.fallback-shop{position:absolute;inset:0}.fallback-shop{display:none}.fallback-world.show-market .fallback-shop{display:block}.fallback-world.show-market .fallback-forge{display:none}
.fallback-world img{display:block;position:absolute;object-fit:contain}.fb-bg{left:0;top:0;width:800px;height:420px}.fb-smith{left:197px;top:86px;width:202px;height:300px;animation:fb-breathe 1.7s ease-in-out infinite alternate}.fb-hammer{left:358px;top:133px;width:100px;height:145px;transform-origin:20% 92%;animation:fb-hammer-idle 2s ease-in-out infinite alternate}.fb-hammer.strike{animation:fb-hammer-smash .42s ease-in-out}.fb-anvil{left:365px;top:225px;width:260px;height:165px}.fb-shop-smith{left:282px;top:152px;width:143px;height:211px;animation:fb-breathe 1.7s ease-in-out infinite alternate}.fb-customer{left:510px;top:133px;width:130px;height:202px;animation:fb-breathe 1.2s ease-in-out infinite alternate;cursor:pointer}.fb-speech{position:absolute;top:95px;left:478px;font-weight:1000;font-size:15px;padding:7px 11px;border-radius:11px;background:#fff4d8;border:3px solid #526384;color:#3b507f}.fb-glow{position:absolute;left:664px;top:166px;width:135px;height:160px;background:#ffdf6d88;border-radius:50%;filter:blur(27px);animation:fb-flicker 1s ease-in-out infinite alternate}.fb-spark{position:absolute;left:475px;top:269px;background:#fff3a0;width:7px;height:7px;border-radius:50%;box-shadow:0 0 15px #ffc55a;animation:fb-sparks 1.8s linear infinite}.fb-spark.two{left:513px;top:255px;animation-delay:.3s}.fb-spark.three{left:547px;top:289px;animation-delay:1s}.fb-effect{position:absolute;top:32%;left:50%;transform:translateX(-50%);font:bold 30px 'Trebuchet MS',sans-serif;text-shadow:0 4px 0 #374b76,-2px -2px 0 #374b76,2px 2px 0 #374b76;color:#fff49c;opacity:0;text-align:center;white-space:nowrap;z-index:10;pointer-events:none}.fb-effect.animated{animation:fb-float .95s ease-out}@keyframes fb-breathe{from{transform:translateY(1px)}to{transform:translateY(-4px)}}@keyframes fb-hammer-idle{from{transform:rotate(-4deg)}to{transform:rotate(5deg)}}@keyframes fb-hammer-smash{0%,100%{transform:rotate(-23deg)}50%{transform:rotate(62deg)}}@keyframes fb-flicker{from{opacity:.2;transform:scale(.92)}to{opacity:.7;transform:scale(1.1)}}@keyframes fb-sparks{0%{transform:translateY(10px) scale(1);opacity:0}20%{opacity:1}100%{transform:translateY(-65px) translateX(23px) scale(.2);opacity:0}}@keyframes fb-float{0%{opacity:0;transform:translate(-50%,20px) scale(.7)}15%{opacity:1}70%{opacity:1}100%{opacity:0;transform:translate(-50%,-35px) scale(1.08)}}
'''
html=f'''<!doctype html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"/><meta name="theme-color" content="#344978"/><title>ANVILBOUND — Animated RPG Preview</title><style>{css}</style></head><body><div id="app"></div><script>{app_js}</script></body></html>'''
path=root.parent/'ANVILBOUND_Animated_Playable_Preview.html';path.write_text(html)
print('wrote',path,'bytes',path.stat().st_size,'compiled modules',[(f.name,len(c)) for f,c in zip(modules,compiled)])
