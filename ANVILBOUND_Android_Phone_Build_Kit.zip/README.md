# ANVILBOUND — Animated Edition

An original, cartoon-style blacksmith & merchant RPG built with **Phaser 3**, **TypeScript**, and **Vite**. Designed primarily for Android portrait displays, also playable on desktop browsers. Source project delivered alongside an offline-capable animated HTML preview.

![Workshop scene](scene_preview.jpg)

## Play the prototype

**Quickest:** Open `../ANVILBOUND_Animated_Playable_Preview.html` in a browser (distributed separately or alongside the source ZIP). It embeds the game systems, UI and artwork in one file. When the browser can fetch Phaser 3.90 from the CDN it renders the Phaser scene; when offline, it uses a CSS-animated fallback workshop with the **same** gameplay and save systems. The preview is therefore usable without installation, but the actual Phaser engine requires loading the library.

**Developer build (Phaser engine):**

Prerequisites: Node.js 20.19+ or 22.12+ and npm; an internet connection for first-time package installation.

```bash
npm install
npm run dev
```

Open the local address printed by Vite. To make a self-contained production HTML build:

```bash
npm run build
npm run preview
```

`npm run build` runs TypeScript checks before Vite. The `vite-plugin-singlefile` plugin embeds JavaScript, CSS and imported art assets in `dist/index.html` so the build can run without external CDN resources. Keep the `dist/` output for packaging.

## Gameplay

- Choose from eight equipment blueprints as they unlock: swords, daggers, shields, staffs, greatswords, rings, armor, and scepters.
- Select normal or advanced material infusions; buy materials from the market.
- Complete three **timed strikes** to determine each item's quality, precision, rarity and stats.
- Animated separate character/hammer/anvil/furnace layers, spark and treasure reveal effects, wandering merchant customer appearances.
- Sell instantly or pay a listing fee to place equipment in the bazaar; set quick, fair, or premium prices.
- Complete customer commissions; market demand and commission deadlines evolve each in-game day.
- Level up to unlock blueprints and infusions, and upgrade your hammer, furnace, trading ability, and network.
- Save automatically in browser storage, manually save, **export JSON**, and import older ANVILBOUND saves.

The gameplay and economy logic is **separate from Phaser** to prevent graphical effects from changing game rules.

## Controls

- Tap or click the **Forge**, **Market**, **Orders**, **Workshop**, **Saves** tabs.
- Select a blueprint and infusion; tap **Ignite the Forge**.
- Tap **STRIKE NOW!** or press **Space** when the moving needle crosses the golden zone. Three strikes finish the item.
- On mobile, the navigation bar stays fixed at the bottom. Scrolling reveals the crafting, inventory and market panels below the animated scene.
- A market visitor can be tapped to open the commission board.

## Project structure

```text
index.html
package.json
vite.config.ts
src/
  main.ts                 Phaser boot and responsive application mount
  game/catalog.ts         Recipes, materials, rarities, events and upgrades
  game/engine.ts          Pure game state, economy, progression, saving
  scenes/WorkshopScene.ts Phaser presentation/animation layer
  ui/ui.ts                Interactive DOM panels and actions
  ui/style.css            Responsive cartoon presentation and accessibility
  assets/                 Imported game art layers
public/assets/             Public item thumbnails and original vector artwork
scripts_make_assets.py     Optional art-layer generator (requires Python packages)
build_standalone.py        Auxiliary HTML preview generator (special local build environment)
tests/                    Headless logic and preview-DOM smoke tests
```

Animation architecture: Phaser's scene holds only visible entities and tween/particle effects. `ForgeGame` owns inventory, timing outcomes, prices, demand, customer orders, XP, and save serialization. DOM UI owns menus and accessibility-friendly controls. Art layers are separately drawable/replaceable, not a single flattened poster.

## Existing saves and backups

The save key remains `anvilbound.save.v1`. The exported portable backup uses `kind: "anvilbound-save"` and `formatVersion: 2` and can import raw version-1 game saves from both earlier ANVILBOUND HTML editions. Import validates data before replacing the current game. Export JSON before updating your browser, clearing app data, or switching devices.

Browser `localStorage` depends on the site's origin. A preview opened from a local file, the Vite dev server, and an Android app can have **different storage locations**. Transfer progress with JSON export/import, not by expecting automatic transfer between them.

## Android APK handoff

This source is not itself an APK. **Capacitor + Android Studio** can wrap the production Vite output as an Android app.

```bash
npm install
npm run build
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npx cap init "ANVILBOUND" "com.emberfall.anvilbound" --web-dir=dist
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

Open the Android project in Android Studio. Use **Build APK(s)** for a local debug APK, or generate a signed APK/AAB for distribution. Set the app to portrait orientation in the Android app configuration if needed; avoid over-constraining large-screen devices. Run device testing before release. Do not assume the browser's local save migrates automatically to an Android app. This package does **not** contain a signed APK.

## Testing & honest limitations

Checks run in the authoring environment:

- Model smoke tests for forge, three strikes, quality/rarity, sales, commission/listings, day progression, inventory, upgrades and save migration.
- DOM integration smoke tests for the self-contained preview, including the offline animation fallback.
- TypeScript game simulation check.
- Visual inspection of composed original scene artwork.

The authoring environment **could not download npm packages** or launch a browser test of the project, so the real Phaser/Vite build and in-browser visuals **are not claimed as production-verified**. Run `npm install && npm run build` and test on actual Android hardware as the next validation step. The standalone preview was smoke-tested with a simulated DOM, not visually captured in a running browser.

## Art and attribution

All SVG-based character layers and item artwork in this prototype were created for ANVILBOUND. Its cartoon fantasy mood draws general inspiration from the user's Rogue Legend reference, without copying any of its character or interface assets. External Phaser/TypeScript/Vite packages retain their own licenses.

## Build Android from an Android phone (no desktop PC)

See **ANDROID_PHONE_ONLY.md**. The project includes a GitHub Actions workflow to compile and upload an Android debug APK entirely in the cloud.
