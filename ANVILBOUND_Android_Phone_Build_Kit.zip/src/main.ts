import Phaser from 'phaser';
import {ForgeGame} from './game/engine';
import {WorkshopScene} from './scenes/WorkshopScene';
import {mountUI} from './ui/ui';
import './ui/style.css';

const model=new ForgeGame();
const scene=new WorkshopScene(model);
mountUI(model,scene);
const game=new Phaser.Game({type:Phaser.AUTO,parent:'game-canvas',width:800,height:420,transparent:false,backgroundColor:'#c4e8ed',scale:{mode:Phaser.Scale.RESIZE,autoCenter:Phaser.Scale.CENTER_BOTH},render:{antialias:true,pixelArt:false},scene:[scene]});
window.addEventListener('pagehide',()=>model.save());
document.addEventListener('visibilitychange',()=>{if(document.hidden)model.save()});
// For end-to-end UI smoke tests only. Not accessed by gameplay logic.
if(import.meta.env.DEV)Object.assign(window,{__ANVILBOUND_DEBUG__:{model,game}});
