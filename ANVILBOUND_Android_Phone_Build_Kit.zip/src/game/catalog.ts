export const materials = {
  iron:{name:'Iron Ingots', icon:'⬟', price:25, desc:'Strong steel for every new blade'},
  wood:{name:'Emberwood', icon:'🌲', price:18, desc:'Seasoned hardwood for handles'},
  leather:{name:'Skyhide Leather', icon:'◈', price:28, desc:'Supple grips and armor lining'},
  silver:{name:'Moonsteel', icon:'⬡', price:92, desc:'Metal that answers to moonlight'},
  gem:{name:'Runestones', icon:'💎', price:130, desc:'Arcane cores from distant ruins'},
  ember:{name:'Dragon Embers', icon:'🔥', price:280, desc:'Rare heat from dragon fire'},
} as const;
export type MaterialKey = keyof typeof materials;
export const materialKeys = Object.keys(materials) as MaterialKey[];
export const recipes = [
 {id:'sword',name:'Adventurer’s Sword',type:'Blade',icon:'⚔️',level:1,base:165,attack:25,defense:4,magic:0,cost:{iron:3,wood:1},desc:'A balanced blade for daring explorers.'},
 {id:'dagger',name:'Twinshadow Dagger',type:'Shadow',icon:'🗡️',level:1,base:145,attack:18,defense:2,magic:2,cost:{iron:2,leather:1},desc:'A quick edge that travels unseen.'},
 {id:'shield',name:'Guardian Shield',type:'Guardian',icon:'🛡️',level:2,base:205,attack:4,defense:32,magic:0,cost:{iron:3,leather:2},desc:'A shield to protect an entire party.'},
 {id:'staff',name:'Mystic Staff',type:'Arcane',icon:'🪄',level:2,base:265,attack:8,defense:4,magic:39,cost:{wood:3,gem:1},desc:'A carved staff for wandering mages.'},
 {id:'greatsword',name:'Colossus Greatblade',type:'Blade',icon:'⚔️',level:3,base:345,attack:49,defense:8,magic:0,cost:{iron:5,silver:1},desc:'A weighty weapon worthy of a hero.'},
 {id:'ring',name:'Starseal Ring',type:'Relic',icon:'💍',level:3,base:440,attack:6,defense:9,magic:35,cost:{silver:2,gem:1},desc:'An enchanted piece for collectors.'},
 {id:'armor',name:'Ironheart Armor',type:'Guardian',icon:'🥋',level:4,base:490,attack:3,defense:67,magic:5,cost:{iron:6,leather:3,silver:1},desc:'Armor that makes a doomed quest possible.'},
 {id:'scepter',name:'Celestial Scepter',type:'Arcane',icon:'🔱',level:5,base:790,attack:12,defense:12,magic:91,cost:{wood:3,silver:2,ember:1},desc:'A relic for royal archmages.'},
] as const;
export type RecipeKey = typeof recipes[number]['id'];
export type ItemType = typeof recipes[number]['type'];
export type MaterialCost = Partial<Record<MaterialKey,number>>;
export const infusions = [
 {id:'standard',name:'Classic Temper',detail:'No additional materials',cost:{} as MaterialCost,level:1,bonus:0},
 {id:'moon',name:'Moonlit Edge',detail:'+1 Moonsteel • finer quality',cost:{silver:1} as MaterialCost,level:2,bonus:8},
 {id:'runic',name:'Runic Binding',detail:'+1 Runestone • arcane quality',cost:{gem:1} as MaterialCost,level:3,bonus:14},
 {id:'dragon',name:'Dragonfire',detail:'+1 Dragon Ember • strongest',cost:{ember:1} as MaterialCost,level:5,bonus:25}
] as const;
export type InfusionKey = typeof infusions[number]['id'];
export const rarities = [
 {name:'Common',color:'#8b8ba7',multi:1,min:0},
 {name:'Fine',color:'#4eae7f',multi:1.38,min:50},
 {name:'Rare',color:'#489bd7',multi:2,min:68},
 {name:'Epic',color:'#af79d9',multi:3.5,min:87},
 {name:'Legendary',color:'#ffc460',multi:6.4,min:105},
 {name:'Mythic',color:'#ff897a',multi:11.7,min:120},
] as const;
export const suffixes: Record<ItemType,string[]>={
 Blade:['Dawncleaver','Oathkeeper','Starfall','Emberguard','Vowbreaker','Kingswake'],
 Shadow:['Quietus','Nightwhisper','Silverstep','Veilpiercer','Duskmarch'],
 Guardian:['Last Bastion','Iron Dawn','Watchfire','Stormwarden','Vanguard'],
 Arcane:['Skyweaver','Dreamsong','Astral Echo','Starcaller','Moonwake'],
 Relic:['Fatebinder','Everlight','First Dawn','Worldsong','Unbroken Promise'],
};
export const clients=[
 {name:'Lyra Windstep',role:'Guild Pathfinder',face:'🧝',quote:'I head into Thistlewood at dawn. I need equipment I can trust.'},
 {name:'Sir Rowan',role:'Knight of the Dawn',face:'🛡️',quote:'An edge is only as honest as the hand that forged it.'},
 {name:'Mira Vale',role:'Arcane Cartographer',face:'🧙',quote:'The ruins whisper in a language my staff cannot understand.'},
 {name:'Kael Thorn',role:'Shadow Broker',face:'🥷',quote:'No questions, smith. Just something quick and quiet.'},
 {name:'Edda Stonewall',role:'Dungeon Vanguard',face:'⚔️',quote:'Sturdy gear please. My last shield didn’t survive.'},
 {name:'Lady Solenne',role:'Royal Envoy',face:'👑',quote:'The royal court will hear of your craftsmanship.'},
 {name:'Nox',role:'Wandering Collector',face:'🧝',quote:'I seek creations nobody else knows how to make.'},
 {name:'Orin Goldcrest',role:'Veteran Delver',face:'🧔',quote:'The next expedition will make us legends.'},
] as const;
export const events=[
 {name:'Northern Pass Reopened',desc:'Caravans need swords and defensive gear.',boost:{Blade:.32,Guardian:.22}},
 {name:'The Moonwake Festival',desc:'Mages and nobles seek arcane curios.',boost:{Arcane:.28,Relic:.35}},
 {name:'Shadow Guild Contract',desc:'Covert missions raise demand for daggers.',boost:{Shadow:.4,Blade:.08}},
 {name:'The Hollow Dungeon Stirs',desc:'Dungeon parties seek armor and staffs.',boost:{Guardian:.32,Arcane:.18}},
 {name:'Royal Tournament',desc:'Challengers want legendary blades and rings.',boost:{Blade:.28,Relic:.23}},
 {name:'A Peaceful Trading Day',desc:'A calmer market rewards patient sellers.',boost:{}},
] as const;
export const types: ItemType[]=['Blade','Shadow','Guardian','Arcane','Relic'];
export const upgrades = {
 hammer:{name:'Hammer Mastery',icon:'🔨',desc:'Increase forging quality and rarity potential.',base:210,scale:1.85},
 furnace:{name:'Ancient Furnace',icon:'🔥',desc:'Higher-quality tempering for rare treasures.',base:340,scale:1.9},
 trade:{name:'Merchant’s Instinct',icon:'⚖️',desc:'Better instant-sale and commission returns.',base:260,scale:1.8},
 network:{name:'Guild Connections',icon:'✨',desc:'Your listings sell more easily and gain prestige.',base:260,scale:1.9},
} as const;
export type UpgradeKey = keyof typeof upgrades;
export const upgradeKeys = Object.keys(upgrades) as UpgradeKey[];
export function recipe(id:string){return recipes.find(r=>r.id===id)||recipes[0]}
export function infusion(id:string){return infusions.find(i=>i.id===id)||infusions[0]}
