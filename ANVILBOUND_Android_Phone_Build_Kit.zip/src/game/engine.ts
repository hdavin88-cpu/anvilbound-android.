import {materials,materialKeys,recipes,recipe,infusions,infusion,rarities,suffixes,clients,events,types,upgrades,upgradeKeys,type MaterialKey,type MaterialCost,type RecipeKey,type InfusionKey,type ItemType,type UpgradeKey} from './catalog';
export type Tab='forge'|'market'|'contracts'|'upgrade'|'save';
export type Strategy='quick'|'fair'|'premium';
export interface Item { id:string;recipe:RecipeKey;type:ItemType;name:string;rank:number;value:number;attack:number;defense:number;magic:number;precision:number;quality:number;qualityLabel:string;infusionName:string;day:number }
export interface Listing {id:string;item:Item;ask:number;mode:Strategy;day:number}
export interface Contract {id:string;client:string;role:string;face:string;quote:string;recipe:RecipeKey;minRank:number;deadline:number;payoutMult:number}
export interface ActiveForge {recipe:RecipeKey;infusion:InfusionKey;cost:MaterialCost;phase:number;scores:number[];cursor:number;direction:1|-1;target:number}
export interface Log {day:number;text:string}
export interface State {version:1;day:number;gold:number;renown:number;level:number;xp:number;materials:Record<MaterialKey,number>;inventory:Item[];listings:Listing[];commission:Contract[];upgrades:Record<UpgradeKey,number>;log:Log[];crafted:number;sold:number;lastAidDay:number;selected:RecipeKey;infusion:InfusionKey;strategy:Strategy;tab:Tab;active:ActiveForge|null;revealed:Item|null;event:number;demand:Record<ItemType,number>;savedAt?:string|null}
export type GameActionResult={ok:boolean;message:string;item?:Item;score?:number;complete?:boolean};
export type SaveStatus={state:'saved'|'unsaved'|'error';lastSaved:string|null;error:string};
export const SAVE_KEY='anvilbound.save.v1';
export const BACKUP_KIND='anvilbound-save';
export const BACKUP_VERSION=2;
const clamp=(v:number,a:number,b:number)=>Math.max(a,Math.min(b,v));
const random=(a:number,b:number)=>a+Math.random()*(b-a);
const chance=(p:number)=>Math.random()<p;
const uid=()=>`f${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`;
const safeText=(v:unknown,fb='',limit=240)=>typeof v==='string'?v.replace(/[<>\u0000-\u001f]/g,'').slice(0,limit):fb;
const safeId=(v:unknown)=>typeof v==='string'&&/^[\w-]{1,70}$/.test(v)?v:uid();
const num=(v:unknown,fb=0,min=0,max=1e10)=>typeof v==='number'&&Number.isFinite(v)?clamp(v,min,max):fb;
const integer=(v:unknown,fb=0,min=0,max=1e10)=>Math.floor(num(v,fb,min,max));
const isRecord=(v:unknown):v is Record<string,any>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const inChoices=(val:unknown,opts:readonly string[])=>typeof val==='string'&&opts.includes(val);
export const fmt=(n:number)=>Math.round(n).toLocaleString('en-US');
export const needXP=(level:number)=>100+level*35+level*level*9;
export function artisanTitle(level:number){return level>=8?'Master of Legends':level>=6?'Royal Artisan':level>=4?'Master Smith':level>=3?'Guild Craftsman':level>=2?'Journeyman Smith':'Unknown Apprentice'}
export function freshState():State{return {version:1,day:1,gold:500,renown:0,level:1,xp:0,materials:{iron:15,wood:9,leather:7,silver:2,gem:1,ember:0},inventory:[],listings:[],commission:[],upgrades:{hammer:0,furnace:0,trade:0,network:0},log:[],crafted:0,sold:0,lastAidDay:0,selected:'sword',infusion:'standard',strategy:'fair',tab:'forge',active:null,revealed:null,event:0,demand:{Blade:1.2,Shadow:1,Guardian:1.03,Arcane:.91,Relic:1.08}}}
function normalizeItem(raw:unknown):Item|null {if(!isRecord(raw)||!recipes.some(r=>r.id===raw.recipe))return null;const r=recipe(raw.recipe);return {id:safeId(raw.id),recipe:r.id,type:r.type,name:safeText(raw.name,r.name,110),rank:integer(raw.rank,0,0,5),value:integer(raw.value,r.base,0,1e11),attack:integer(raw.attack,0,0,1e5),defense:integer(raw.defense,0,0,1e5),magic:integer(raw.magic,0,0,1e5),precision:integer(raw.precision,0,0,100),quality:integer(raw.quality,0,0,300),qualityLabel:safeText(raw.qualityLabel,'Well-made',40),infusionName:safeText(raw.infusionName,'Classic Temper',50),day:integer(raw.day,1,1,1e8)}}
/** Accept v1 raw saves from both original ANVILBOUND HTML games, without changing the economic model. */
export function normalizeGame(raw:unknown):State {
 if(!isRecord(raw))throw Error('Not a valid ANVILBOUND save.');
 if(raw.version!=null&&raw.version!==1)throw Error('Unsupported game version.');
 if(!Number.isInteger(raw.day)||raw.day<1||!Number.isFinite(raw.gold)||!Number.isInteger(raw.level)||raw.level<1||!isRecord(raw.materials)||!isRecord(raw.upgrades)||!Array.isArray(raw.inventory)||!Array.isArray(raw.listings)||!Array.isArray(raw.commission))throw Error('Missing or invalid game progress. No changes made.');
 const s=freshState();s.day=integer(raw.day,1,1,1e8);s.gold=integer(raw.gold,500,0,1e12);s.renown=integer(raw.renown,0,0,1e10);s.level=integer(raw.level,1,1,500);s.xp=integer(raw.xp,0);s.crafted=integer(raw.crafted,0);s.sold=integer(raw.sold,0);s.lastAidDay=integer(raw.lastAidDay,0);s.event=integer(raw.event,0,0,events.length-1);
 s.selected=(recipes.some(r=>r.id===raw.selected)?raw.selected:'sword') as RecipeKey;
 s.infusion=(infusions.some(i=>i.id===raw.infusion)?raw.infusion:'standard') as InfusionKey;
 s.strategy=(inChoices(raw.strategy,['quick','fair','premium'])?raw.strategy:'fair') as Strategy;
 s.tab=(inChoices(raw.tab,['forge','market','contracts','upgrade','save'])?raw.tab:'forge') as Tab;
 for(const k of materialKeys)s.materials[k]=integer(raw.materials[k],s.materials[k]);
 for(const k of upgradeKeys)s.upgrades[k]=integer(raw.upgrades[k],0,0,5);
 for(const k of types)s.demand[k]=num(raw.demand?.[k],s.demand[k],.2,3);
 s.inventory=raw.inventory.slice(0,10000).map(normalizeItem).filter((v:Item|null):v is Item=>v!==null);
 s.listings=raw.listings.slice(0,10000).map((l:unknown)=>{if(!isRecord(l))return null;const item=normalizeItem(l.item);if(!item)return null;return {id:safeId(l.id),item,ask:integer(l.ask,item.value,0,1e12),mode:(inChoices(l.mode,['quick','fair','premium'])?l.mode:'fair') as Strategy,day:integer(l.day,s.day,1,1e8)}}).filter((v:Listing|null):v is Listing=>v!==null);
 s.commission=raw.commission.slice(0,100).map((c:unknown)=>{if(!isRecord(c)||!recipes.some(r=>r.id===c.recipe))return null;return {id:safeId(c.id),client:safeText(c.client,'Adventurer',90),role:safeText(c.role,'Guild patron',90),face:safeText(c.face,'✦',16),quote:safeText(c.quote,'A fine commission.',250),recipe:c.recipe as RecipeKey,minRank:integer(c.minRank,0,0,5),deadline:integer(c.deadline,s.day+3,1,1e8),payoutMult:num(c.payoutMult,1.4,.1,100)}}).filter((v:Contract|null):v is Contract=>v!==null);
 s.log=(Array.isArray(raw.log)?raw.log:[]).slice(0,20).map((l:unknown)=>({day:integer(isRecord(l)?l.day:undefined,s.day,1,1e8),text:safeText(isRecord(l)?l.text:undefined,'',350)}));
 if(isRecord(raw.active)&&recipes.some(r=>r.id===raw.active.recipe)){
  const a=raw.active;const inf=(infusions.some(f=>f.id===a.infusion)?a.infusion:'standard') as InfusionKey;
  const cost=combinedCost(a.recipe as RecipeKey,inf);
  s.active={recipe:a.recipe as RecipeKey,infusion:inf,cost,phase:integer(a.phase,0,0,2),scores:(Array.isArray(a.scores)?a.scores:[]).slice(0,2).map((v:unknown)=>integer(v,50,0,100)),cursor:num(a.cursor,.05,0,1),direction:a.direction===-1?-1:1,target:num(a.target,.5,.1,.9)};
 }
 s.savedAt=typeof raw.savedAt==='string'&&!Number.isNaN(Date.parse(raw.savedAt))?raw.savedAt:null;
 return s;
}
export function combinedCost(recipeId:RecipeKey,infId:InfusionKey):MaterialCost {const r=recipe(recipeId),f=infusion(infId);const cost:MaterialCost={...r.cost};for(const [k,v] of Object.entries(f.cost))cost[k as MaterialKey]=(cost[k as MaterialKey]||0)+(v as number);return cost}
export function unpackBackup(data:unknown):State {if(isRecord(data)&&data.kind===BACKUP_KIND){if(data.formatVersion!==BACKUP_VERSION)throw Error('Unsupported backup format.');return normalizeGame(data.data);}return normalizeGame(data)}
export class ForgeGame {
 state:State;status:SaveStatus={state:'unsaved',lastSaved:null,error:''};
 onChange:(()=>void)|null=null;
 onNotice:((message:string)=>void)|null=null;
 constructor(){let broken=false;try{const saved=localStorage.getItem(SAVE_KEY);if(saved){this.state=normalizeGame(JSON.parse(saved));this.status={state:'saved',lastSaved:this.state.savedAt||null,error:''};}else this.state=freshState();}catch(e){broken=true;this.state=freshState();this.status={state:'error',lastSaved:null,error:e instanceof Error?e.message:'Local storage unavailable'};}
 if(!this.state.commission.length)this.seedContracts();if(!this.state.log.length){this.newDemand();this.log('You inherit a humble forge in Emberfall. Your legend is unwritten.');}
 if(!broken&&this.status.state==='unsaved')this.save();
 }
 emit(){this.onChange?.()}
 message(m:string){this.onNotice?.(m)}
 persist(m?:string){this.save();this.emit();if(m)this.message(m)}
 save():boolean {try{const now=new Date().toISOString();localStorage.setItem(SAVE_KEY,JSON.stringify({...this.state,savedAt:now,revealed:null}));this.state.savedAt=now;this.status={state:'saved',lastSaved:now,error:''};return true;}catch(e){this.status={state:'error',lastSaved:null,error:e instanceof Error?e.message:'Storage blocked'};return false;}}
 manualSave(){const ok=this.save();this.emit();this.message(ok?'Workshop saved to this browser.':'Storage blocked. Export a backup instead.');}
 import(raw:unknown){const candidate=unpackBackup(raw);this.state=candidate;this.state.tab='save';this.state.revealed=null;this.persist('Backup restored. Save it on this browser or export another backup.');}
 exportData(){return {kind:BACKUP_KIND,formatVersion:BACKUP_VERSION,exportedAt:new Date().toISOString(),data:JSON.parse(JSON.stringify({...this.state,revealed:null}))}}
 reset(){this.state=freshState();this.newDemand();this.seedContracts();this.log('The guild grants you a new workshop.');this.persist('Your adventure has restarted.');}
 setTab(tab:Tab){this.state.tab=tab;this.persist();}
 setRecipe(key:RecipeKey){if(!this.state.active&&recipes.some(r=>r.id===key&&r.level<=this.state.level)){this.state.selected=key;this.persist();}}
 setInfusion(key:InfusionKey){if(!this.state.active&&infusions.some(f=>f.id===key&&f.level<=this.state.level)){this.state.infusion=key;this.persist();}}
 setStrategy(mode:Strategy){this.state.strategy=mode;this.persist();}
 log(text:string){this.state.log.unshift({day:this.state.day,text});this.state.log=this.state.log.slice(0,20)}
 gainXP(amount:number){this.state.xp+=amount;let levels=0;while(this.state.xp>=needXP(this.state.level)){this.state.xp-=needXP(this.state.level);this.state.level++;levels++}if(levels)this.log(`LEVEL UP! You reached level ${this.state.level}.`);return levels>0}
 totalCost(){return combinedCost(this.state.selected,this.state.infusion)}
 hasMaterials(cost:MaterialCost){return Object.entries(cost).every(([k,v])=>this.state.materials[k as MaterialKey]>=(v||0))}
 canAid(){const s=this.state;if(s.active||s.inventory.length||s.listings.length||s.lastAidDay===s.day)return false;const unlocked=recipes.filter(r=>r.level<=s.level);if(unlocked.some(r=>this.hasMaterials(r.cost)))return false;const cheapest=Math.min(...unlocked.map(r=>Object.entries(r.cost).reduce((sum,[k,n])=>sum+Math.max(0,n-(s.materials[k as MaterialKey]||0))*this.marketPrice(k as MaterialKey),0)));return s.gold<cheapest}
 aid(){if(!this.canAid())return this.fail('Guild relief is not needed.');this.state.materials.iron+=3;this.state.materials.wood++;this.state.gold+=20;this.state.lastAidDay=this.state.day;this.log('Received guild relief: 3 iron, 1 wood, 20 gold.');this.persist('The guild has provided emergency supplies!');return this.ok('Guild supplies received.')}
 itemValue(item:Item){return Math.round(item.value*(this.state.demand[item.type]||1))}
 marketPrice(k:MaterialKey){const wiggle=1+Math.sin((this.state.day+materialKeys.indexOf(k)*3)*1.7)*.07;return Math.round(materials[k].price*wiggle*(1-Math.min(this.state.renown,120)*.00045))}
 instantValue(item:Item){return Math.round(this.itemValue(item)*(.73+this.state.upgrades.trade*.043))}
 listingTerms(item:Item,mode:Strategy){const mult=mode==='quick'?.9:mode==='premium'?1.5:1.1;return {ask:Math.round(this.itemValue(item)*mult),fee:Math.max(3,Math.round(this.itemValue(item)*mult*.03))}}
 contractPayout(item:Item,c:Contract){return Math.round(this.itemValue(item)*c.payoutMult*(1+this.state.upgrades.trade*.065))}
 upgradePrice(k:UpgradeKey){return Math.round(upgrades[k].base*Math.pow(upgrades[k].scale,this.state.upgrades[k]))}
 newDemand(){this.state.event=(this.state.day-1)%events.length;const evt=events[this.state.event];types.forEach((t,i)=>{const wave=Math.sin(this.state.day*1.31+i*2.12)*.12;const boost=(evt.boost as Partial<Record<ItemType,number>>)[t]||0;this.state.demand[t]=Math.round(clamp(.91+wave+boost,.65,1.65)*100)/100})}
 newContract():Contract{const rs=recipes.filter(r=>r.level<=this.state.level);const r=rs[Math.floor(random(0,rs.length))],c=clients[Math.floor(random(0,clients.length))];const minRank=this.state.level<=2?(chance(.3)?1:0):Math.min(4,Math.max(0,Math.floor(this.state.level/2)-1)+(chance(.25)?1:0));return {id:uid(),client:c.name,role:c.role,face:c.face,quote:c.quote,recipe:r.id,minRank,deadline:this.state.day+3+Math.floor(random(0,2)),payoutMult:1.43+minRank*.18+this.state.upgrades.trade*.08}}
 seedContracts(){while(this.state.commission.length<3)this.state.commission.push(this.newContract())}
 startForge():GameActionResult{if(this.state.active)return this.fail('Complete your current item first.');const cost=this.totalCost();if(!this.hasMaterials(cost))return this.fail('Not enough supplies. Buy materials at the market.');for(const [k,v] of Object.entries(cost))this.state.materials[k as MaterialKey]-=v||0;this.state.active={recipe:this.state.selected,infusion:this.state.infusion,cost,phase:0,scores:[],cursor:.05,direction:1,target:random(.3,.7)};this.log(`The forge begins shaping ${recipe(this.state.selected).name}.`);this.persist('Forging started! Time your three hammer strikes.');return this.ok('Forging started.')}
 tick(dt:number){const a=this.state.active;if(!a)return;const speed=.00048+.000095*a.phase+.000018*this.state.level;const next=a.cursor+clamp(dt,0,80)*speed*a.direction;if(next>=1){a.cursor=2-next;a.direction=-1}else if(next<=0){a.cursor=-next;a.direction=1}else a.cursor=next}
 strike():GameActionResult{const a=this.state.active;if(!a)return this.fail('Ignite a blueprint before striking.');const delta=Math.abs(a.cursor-a.target);const score=Math.round(clamp(104-delta*225,8,100));a.scores.push(score);a.phase++;if(a.phase>=3)return {...this.finishForge(),score,complete:true};a.cursor=.03;a.direction=1;a.target=random(.28,.72);this.persist(score>=93?'PERFECT STRIKE! ✨':score>=72?'Well struck!':'The metal resists...');return {ok:true,message:'Strike recorded.',score,complete:false}}
 finishForge():GameActionResult{const a=this.state.active;if(!a)return this.fail('No equipment is being forged.');const r=recipe(a.recipe),f=infusion(a.infusion);const precision=Math.round(a.scores.reduce((x,y)=>x+y,0)/3);const quality=Math.round(precision*.77+23+this.state.upgrades.hammer*4+this.state.upgrades.furnace*4+f.bonus+random(-11,11));let rank=0;for(let i=1;i<rarities.length;i++)if(quality>=rarities[i].min)rank=i;
 if(rank<=3&&precision>=85&&chance(.002+this.state.upgrades.furnace*.004+(f.id==='dragon'?.023:0)))rank=Math.min(5,rank+2);
 const rare=rarities[rank],value=Math.round(r.base*(.78+precision*.0065)*rare.multi*(1+f.bonus*.007)),traits=suffixes[r.type],trait=traits[Math.floor(Math.random()*traits.length)],archetype:Record<RecipeKey,string>={sword:'Sword',dagger:'Dagger',shield:'Shield',staff:'Staff',greatsword:'Greatblade',ring:'Ring',armor:'Armor',scepter:'Scepter'},itemName=rank>=4?`The ${trait} ${archetype[r.id]}`:rank>=3?`${trait} ${archetype[r.id]}`:rank>=1?`${trait} ${r.name}`:r.name;
 const mult=(.65+precision*.0045)*(1+rank*.17)+f.bonus*.003;
 const item:Item={id:uid(),recipe:r.id,type:r.type,name:itemName,rank,value,attack:Math.round(r.attack*mult),defense:Math.round(r.defense*mult),magic:Math.round(r.magic*mult),precision,quality,qualityLabel:precision>=92?'Flawless':precision>=72?'Refined':precision>=50?'Well-made':'Rough-hewn',infusionName:f.name,day:this.state.day};
 this.state.inventory.push(item);this.state.crafted++;this.state.active=null;this.state.revealed=item;this.state.renown+=Math.max(1,Math.floor(rank/2))+this.state.upgrades.network*.2;this.state.renown=Math.floor(this.state.renown);this.gainXP(28+Math.round(precision*.32)+rank*21);this.log(`Forged ${item.name} · ${rare.name}, appraised at ${fmt(value)} G.`);this.persist(rank>=3?'A MASTERPIECE EMERGES! ✨':'New equipment ready!');return {ok:true,message:'Item forged',item,complete:true}}
 dismissItem(){this.state.revealed=null;this.persist()}
 inspect(itemId:string){const item=this.state.inventory.find(x=>x.id===itemId);if(!item)return this.fail('Item not found.');this.state.revealed=item;this.emit();return this.ok('Inspecting item.',item)}
 sellInstant(itemId:string):GameActionResult{const idx=this.state.inventory.findIndex(x=>x.id===itemId);if(idx<0)return this.fail('Item not found.');const [item]=this.state.inventory.splice(idx,1);const n=this.instantValue(item);this.state.gold+=n;this.state.sold++;this.state.renown+=Math.max(1,Math.ceil(item.rank*.8));this.gainXP(8+item.rank*6);this.log(`Sold ${item.name} for ${fmt(n)} G.`);this.persist(`SOLD! +${fmt(n)} Gold`);return this.ok('Item sold.');}
 listItem(itemId:string):GameActionResult{const idx=this.state.inventory.findIndex(x=>x.id===itemId);if(idx<0)return this.fail('Item not found.');const item=this.state.inventory[idx],{ask,fee}=this.listingTerms(item,this.state.strategy);if(this.state.gold<fee)return this.fail(`Need ${fee} G stall fee.`);this.state.inventory.splice(idx,1);this.state.gold-=fee;this.state.listings.push({id:uid(),item,ask,mode:this.state.strategy,day:this.state.day});this.log(`Listed ${item.name} in the bazaar for ${fmt(ask)} G.`);this.persist(`Listed for ${fmt(ask)} G. Advance the day to attract buyers.`);return this.ok('Item listed.');}
 cancelListing(listId:string){const idx=this.state.listings.findIndex(x=>x.id===listId);if(idx<0)return this.fail('Listing not found.');const [l]=this.state.listings.splice(idx,1);this.state.inventory.push(l.item);this.persist('Item returned to inventory. Listing fee is not refunded.');return this.ok('Listing recalled.')}
 buyMaterial(k:MaterialKey):GameActionResult{if(!materials[k])return this.fail('Material unknown.');const price=this.marketPrice(k);if(this.state.gold<price)return this.fail('Not enough gold.');this.state.gold-=price;this.state.materials[k]++;this.log(`Bought 1 ${materials[k].name} for ${price} G.`);this.persist(`+1 ${materials[k].name}`);return this.ok('Materials purchased.')}
 fulfill(id:string):GameActionResult{const idx=this.state.commission.findIndex(c=>c.id===id);if(idx<0)return this.fail('Commission not found.');const c=this.state.commission[idx];const item=this.state.inventory.filter(i=>i.recipe===c.recipe&&i.rank>=c.minRank).sort((a,b)=>a.value-b.value)[0];if(!item)return this.fail('Forge matching equipment of sufficient rarity.');const payout=this.contractPayout(item,c);this.state.inventory=this.state.inventory.filter(i=>i.id!==item.id);this.state.gold+=payout;this.state.sold++;const renown=4+item.rank*2+this.state.upgrades.network;this.state.renown+=renown;this.gainXP(33+item.rank*20);this.state.commission.splice(idx,1);this.state.commission.push(this.newContract());this.log(`Delivered ${item.name} to ${c.client} for ${fmt(payout)} G.`);this.persist(`COMMISSION COMPLETE! +${fmt(payout)} Gold · +${renown} Fame`);return this.ok('Commission completed.')}
 upgrade(k:UpgradeKey):GameActionResult{if(!upgrades[k]||this.state.upgrades[k]>=5)return this.fail('Upgrade unavailable.');const cost=this.upgradePrice(k);if(this.state.gold<cost)return this.fail('Save more gold first.');this.state.gold-=cost;this.state.upgrades[k]++;this.log(`${upgrades[k].name} reaches level ${this.state.upgrades[k]}.`);this.persist(`${upgrades[k].name} upgraded!`);return this.ok('Workshop upgraded.')}
 endDay():GameActionResult{if(this.state.active)return this.fail('Complete forging before ending the day.');const s=this.state;s.day++;for(let i=s.listings.length-1;i>=0;i--){const l=s.listings[i],age=s.day-l.day,prob=(l.mode==='quick'?.88:l.mode==='fair'?.63:.39)+s.upgrades.network*.07+Math.min(s.renown,150)*.00055;if(chance(clamp(prob,0,.97))){s.gold+=l.ask;s.sold++;s.renown+=Math.max(1,Math.ceil(l.item.rank*.95));this.gainXP(10+l.item.rank*6);this.log(`Bazaar sale! ${l.item.name} sold for ${fmt(l.ask)} G.`);s.listings.splice(i,1)}else if(age>=4){s.inventory.push(l.item);this.log(`No buyer for ${l.item.name}; returned to inventory.`);s.listings.splice(i,1)}}const expired=s.commission.filter(c=>c.deadline<s.day).length;if(expired){s.renown=Math.max(0,s.renown-expired);this.log(`${expired} commission(s) expired.`)}s.commission=s.commission.filter(c=>c.deadline>=s.day);this.seedContracts();this.newDemand();const upkeep=6+s.level*2;if(s.gold>=upkeep){s.gold-=upkeep;this.log(`Workshop upkeep: ${upkeep} G.`)}else this.log('Guild waived upkeep while treasury is empty.');this.log(`Day ${s.day}: ${events[s.event].name}.`);this.persist(`DAY ${s.day} • ${events[s.event].name}`);return this.ok('New day started.')}
 private ok(message:string,item?:Item):GameActionResult{return {ok:true,message,item}}
 private fail(message:string):GameActionResult{this.message(message);return {ok:false,message}}
}
