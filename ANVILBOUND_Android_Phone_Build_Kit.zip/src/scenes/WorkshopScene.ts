import Phaser from 'phaser';
import type {ForgeGame,Item,Tab} from '../game/engine';
import forgeBg from '../assets/forge-bg.png';
import smithImg from '../assets/smith.png';
import hammerImg from '../assets/hammer.png';
import anvilImg from '../assets/anvil.png';
import shopBg from '../assets/shop-bg.png';
import knightImg from '../assets/knight.png';
import mageImg from '../assets/mage.png';
import rangerImg from '../assets/ranger.png';

/** The Phaser scene is presentation-only. ForgeGame owns all gold, items, and rules. */
export class WorkshopScene extends Phaser.Scene {
 public model: ForgeGame;
 public onFrame: ((cursor:number,target:number,phase:number)=>void)|null=null;
 private forgeLayer!:Phaser.GameObjects.Container;
 private shopLayer!:Phaser.GameObjects.Container;
 private smith!:Phaser.GameObjects.Image;
 private hammer!:Phaser.GameObjects.Image;
 private weapon!:Phaser.GameObjects.Image;
 private customer!:Phaser.GameObjects.Image;
 private shopCustomerName!:Phaser.GameObjects.Text;
 private sparklers:Phaser.GameObjects.Arc[]=[];
 private furnaceGlow!:Phaser.GameObjects.Arc;
 private lastTab:Tab='forge';
 private visitorNumber=0;
 private customerTimer?:Phaser.Time.TimerEvent;
 private reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
 private customerNames=['Sir Rowan','Mira Vale','Lyra Windstep'];
 constructor(model:ForgeGame){super({key:'WorkshopScene'});this.model=model;}
 preload(){
  for(const [key,url] of Object.entries({forgeBg,smithImg,hammerImg,anvilImg,shopBg,knightImg,mageImg,rangerImg}))this.load.image(key,url);
 }
 create(){
  this.cameras.main.setBackgroundColor('#b7e3e9');
  this.forgeLayer=this.add.container(0,0);
  this.shopLayer=this.add.container(0,0);
  const addImage=(container:Phaser.GameObjects.Container,key:string,x:number,y:number,w:number,h:number)=>{
   const im=this.add.image(x,y,key).setOrigin(0).setDisplaySize(w,h);container.add(im);return im;
  };
  addImage(this.forgeLayer,'forgeBg',0,0,800,420);
  this.furnaceGlow=this.add.ellipse(690,214,132,155,0xffc04d,.08);
  this.forgeLayer.add(this.furnaceGlow);
  this.smith=addImage(this.forgeLayer,'smithImg',197,86,202,300);
  this.hammer=this.add.image(378,267,'hammerImg').setOrigin(.20,.925).setDisplaySize(100,145);
  this.forgeLayer.add(this.hammer);
  this.weapon=addImage(this.forgeLayer,'anvilImg',365,225,260,165);
  const forgemark=this.add.text(24,17,'✦  THE HEARTFIRE ANVIL',{fontFamily:'Trebuchet MS, sans-serif',fontSize:'18px',fontStyle:'bold',color:'#fff4ca',stroke:'#32486c',strokeThickness:5});
  this.forgeLayer.add(forgemark);
  const sceneTip=this.add.text(25,370,'HAMMER • HEAT • HEROES',{fontFamily:'Trebuchet MS, sans-serif',fontSize:'16px',fontStyle:'bold',color:'#fff5c3',stroke:'#46506e',strokeThickness:5});
  this.forgeLayer.add(sceneTip);
  this.makeEmbers();
  addImage(this.shopLayer,'shopBg',0,0,800,420);
  const shopSmith=addImage(this.shopLayer,'smithImg',282,152,143,211);
  const counterText=this.add.text(40,17,'✦  THE EMBERFALL MARKET',{fontFamily:'Trebuchet MS, sans-serif',fontSize:'18px',fontStyle:'bold',color:'#fff4ca',stroke:'#32486c',strokeThickness:5});this.shopLayer.add(counterText);
  this.customer=addImage(this.shopLayer,'knightImg',800,133,130,202).setInteractive({useHandCursor:true});
  this.customer.on('pointerdown',()=>{this.model.setTab('contracts');this.setTab('contracts');});
  this.shopCustomerName=this.add.text(470,115,'Sir Rowan is browsing…',{fontFamily:'Trebuchet MS, sans-serif',fontSize:'14px',fontStyle:'bold',color:'#40517b',backgroundColor:'#fff4d8',padding:{x:10,y:6}}).setOrigin(.5).setVisible(false);
  this.shopLayer.add(this.shopCustomerName);
  this.tweens.add({targets:shopSmith,y:shopSmith.y-4,duration:1050,ease:'Sine.InOut',yoyo:true,repeat:-1});
  if(!this.reducedMotion){
   this.tweens.add({targets:this.smith,y:83,duration:1250,ease:'Sine.InOut',repeat:-1,yoyo:true});
   this.tweens.add({targets:this.hammer,angle:-7,duration:1250,ease:'Sine.InOut',repeat:-1,yoyo:true});
   this.tweens.add({targets:this.furnaceGlow,alpha:.26,scaleX:1.2,scaleY:1.1,duration:720,repeat:-1,yoyo:true,ease:'Sine.InOut'});
  }
  this.lastTab=this.model.state.tab;
  this.setTab(this.lastTab);
  this.scale.on(Phaser.Scale.Events.RESIZE,this.resizeScene,this);
  this.resizeScene();
  this.events.on(Phaser.Scenes.Events.SHUTDOWN,()=>this.scale.off(Phaser.Scale.Events.RESIZE,this.resizeScene,this));
 }
 private resizeScene(){const w=this.scale.width,h=this.scale.height;const zoom=h/420;this.cameras.main.setViewport(0,0,w,h);this.cameras.main.setZoom(zoom);this.cameras.main.centerOn(400,210);}
 private makeEmbers(){
  for(let i=0;i<17;i++){
   const c=this.add.circle(610+Math.random()*175,235+Math.random()*105,1.8+Math.random()*2.5,Math.random()>.5?0xffdb66:0xff824d,.8);
   this.forgeLayer.add(c);this.sparklers.push(c);
   if(!this.reducedMotion)this.tweens.add({targets:c,y:c.y-60-Math.random()*70,x:c.x+(Math.random()-.5)*35,alpha:0,scale:0,duration:1200+Math.random()*1200,delay:i*120,repeat:-1,onRepeat:()=>{c.x=610+Math.random()*170;c.y=245+Math.random()*80;c.alpha=.9;c.scale=1}});
  }
 }
 public setTab(tab:Tab){if(!this.forgeLayer||!this.shopLayer)return;const market=tab==='market'||tab==='contracts';this.forgeLayer.setVisible(!market);this.shopLayer.setVisible(market);if(market&&(this.lastTab!=='market'&&this.lastTab!=='contracts'))this.walkInCustomer();this.lastTab=tab;}
 private walkInCustomer(){if(!this.customer)return;this.customerTimer?.remove(false);this.tweens.killTweensOf(this.customer);this.visitorNumber=(this.visitorNumber+1)%3;const keys=['knightImg','mageImg','rangerImg'];const name=this.customerNames[this.visitorNumber];this.customer.setTexture(keys[this.visitorNumber]);this.customer.setDisplaySize(130,202);this.customer.setPosition(790,133);this.shopCustomerName.setText(`${name} is browsing…`).setVisible(false);
  if(this.reducedMotion){this.customer.x=518;this.shopCustomerName.setVisible(true);return;}
  this.tweens.add({targets:this.customer,x:518,duration:2100,ease:'Sine.Out',onComplete:()=>{this.shopCustomerName.setVisible(true);this.customerTimer=this.time.delayedCall(6800,()=>{this.shopCustomerName.setVisible(false);this.tweens.add({targets:this.customer,x:790,duration:1300,onComplete:()=>{if(this.shopLayer.visible)this.walkInCustomer()}});});}});
  this.tweens.add({targets:this.customer,y:128,duration:145,yoyo:true,repeat:14,ease:'Sine.InOut'});
 }
 public strikeEffect(score:number,complete:boolean){
  this.tweens.killTweensOf(this.hammer);
  if(this.reducedMotion){this.burst(493,275,complete?35:16,complete?0xf7d15b:0xffbe5a);return}
  this.tweens.add({targets:this.hammer,angle:55,duration:110,ease:'Quad.In',onComplete:()=>{
    this.cameras.main.shake(85,.0022);this.burst(491,275,complete?32:20,score>=90?0xfff6b7:0xffb95c);
    this.addFloatingText(score>=92?'PERFECT!':score>=75?'GREAT HIT!':`${score} PTS`,495,219,score>=90?'#fff6b0':'#ffffff');
    this.tweens.add({targets:this.hammer,angle:-22,duration:220,ease:'Back.Out',onComplete:()=>{this.tweens.add({targets:this.hammer,angle:-5,duration:300})}});
  }});
 }
 public levelUpEffect(){this.burst(303,192,32,0xb8f7ff);this.addFloatingText('LEVEL UP!',305,83,'#fff6a2');}
 public saleEffect(){this.burst(516,233,17,0xffdb61);this.addFloatingText('+ GOLD!',520,178,'#fff1ae');}
 public revealEffect(item:Item){const tint=item.rank>=4?0xffd466:item.rank>=2?0x9cc9ff:0xbff5d6;this.burst(486,255,item.rank>=3?55:28,tint);if(item.rank>=3)this.cameras.main.flash(260,255,244,188);}
 private addFloatingText(message:string,x:number,y:number,color:string){const t=this.add.text(x,y,message,{fontFamily:'Trebuchet MS, sans-serif',fontSize:'27px',fontStyle:'bold',color,stroke:'#3b4568',strokeThickness:6}).setOrigin(.5);t.setDepth(10);this.tweens.add({targets:t,y:y-62,alpha:0,duration:950,ease:'Sine.Out',onComplete:()=>t.destroy()});}
 private burst(x:number,y:number,count:number,tint:number){for(let i=0;i<count;i++){const angle=Math.random()*Math.PI*2,dist=25+Math.random()*105;const p=this.add.star(x,y,4,1.5+Math.random()*2.2,4+Math.random()*5,tint,.95).setDepth(8);this.tweens.add({targets:p,x:x+Math.cos(angle)*dist,y:y+Math.sin(angle)*dist,alpha:0,scale:0,angle:Math.random()*170,duration:380+Math.random()*400,ease:'Cubic.Out',onComplete:()=>p.destroy()});}}
 update(_t:number,dt:number){if(document.visibilityState==='hidden')return;this.model.tick(dt);const a=this.model.state.active;if(a)this.onFrame?.(a.cursor,a.target,a.phase);}
}
